Version 0.3.0 (December 24th 2017)
------------------------------
 * changed state type to simplify the code
 * Library is written in typescript

Version 0.2.1 (October 26th 2016)
------------------------------
 * setStatus() function modified. Removed useless else statement

Version 0.2.0 (October 22th 2016)
------------------------------
 * Updated for open source release on GitHub
 * Code reworked
 * Dedicated website
 * Documentation
 * Examples

Version 0.1.0 (December 1st 2015)
-----------------------------
 * initial version
